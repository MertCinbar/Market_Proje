﻿namespace MarketProje
{
    partial class FormMusteri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMusteri));
            sampPictureBox = new PictureBox();
            deterjanPictureBox = new PictureBox();
            cipsPictureBox = new PictureBox();
            sebzePictureBox = new PictureBox();
            suPictureBox = new PictureBox();
            cikoPictureBox = new PictureBox();
            meyvePictureBox = new PictureBox();
            colaPictureBox = new PictureBox();
            cheesePictureBox = new PictureBox();
            eggPictureBox = new PictureBox();
            milkPictureBox = new PictureBox();
            ekmekPictureBox = new PictureBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel3 = new Panel();
            button2 = new Button();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)sampPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)deterjanPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cipsPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sebzePictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)suPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cikoPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)meyvePictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)colaPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cheesePictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)eggPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)milkPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ekmekPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // sampPictureBox
            // 
            sampPictureBox.BackColor = SystemColors.ControlLightLight;
            sampPictureBox.Cursor = Cursors.Hand;
            sampPictureBox.Image = Resource1.grooming_salon_care_animal_pet_shampoo_cat_icon_260121;
            sampPictureBox.Location = new Point(394, 327);
            sampPictureBox.Name = "sampPictureBox";
            sampPictureBox.Size = new Size(200, 109);
            sampPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            sampPictureBox.TabIndex = 13;
            sampPictureBox.TabStop = false;
            sampPictureBox.Click += sampPictureBox_Click;
            // 
            // deterjanPictureBox
            // 
            deterjanPictureBox.BackColor = SystemColors.ControlLightLight;
            deterjanPictureBox.Cursor = Cursors.Hand;
            deterjanPictureBox.Image = Resource1.hygiene_cleaning_cleaner_clean_detergent_icon_224915;
            deterjanPictureBox.Location = new Point(198, 327);
            deterjanPictureBox.Name = "deterjanPictureBox";
            deterjanPictureBox.Size = new Size(200, 109);
            deterjanPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            deterjanPictureBox.TabIndex = 12;
            deterjanPictureBox.TabStop = false;
            deterjanPictureBox.Click += deterjanPictureBox_Click;
            // 
            // cipsPictureBox
            // 
            cipsPictureBox.BackColor = SystemColors.ControlLightLight;
            cipsPictureBox.Cursor = Cursors.Hand;
            cipsPictureBox.Image = Resource1.french_fries_chips_potatoes_food_fast_food_icon_207923;
            cipsPictureBox.Location = new Point(3, 327);
            cipsPictureBox.Name = "cipsPictureBox";
            cipsPictureBox.Size = new Size(200, 109);
            cipsPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            cipsPictureBox.TabIndex = 11;
            cipsPictureBox.TabStop = false;
            cipsPictureBox.Click += cipsPictureBox_Click;
            // 
            // sebzePictureBox
            // 
            sebzePictureBox.BackColor = SystemColors.ControlLightLight;
            sebzePictureBox.Cursor = Cursors.Hand;
            sebzePictureBox.Image = Resource1.picnicbasketfullofrawvegetables_114673;
            sebzePictureBox.Location = new Point(394, 220);
            sebzePictureBox.Name = "sebzePictureBox";
            sebzePictureBox.Size = new Size(200, 109);
            sebzePictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            sebzePictureBox.TabIndex = 10;
            sebzePictureBox.TabStop = false;
            sebzePictureBox.Click += sebzePictureBox_Click;
            // 
            // suPictureBox
            // 
            suPictureBox.BackColor = SystemColors.ControlLightLight;
            suPictureBox.Cursor = Cursors.Hand;
            suPictureBox.Image = Resource1.fresh_drink_bottle_water_mineral_beverage_icon_258825__1_;
            suPictureBox.Location = new Point(198, 220);
            suPictureBox.Name = "suPictureBox";
            suPictureBox.Size = new Size(200, 109);
            suPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            suPictureBox.TabIndex = 9;
            suPictureBox.TabStop = false;
            suPictureBox.Click += suPictureBox_Click;
            // 
            // cikoPictureBox
            // 
            cikoPictureBox.BackColor = SystemColors.ControlLightLight;
            cikoPictureBox.Cursor = Cursors.Hand;
            cikoPictureBox.Image = Resource1.ice_cream_icon_126068;
            cikoPictureBox.Location = new Point(3, 220);
            cikoPictureBox.Name = "cikoPictureBox";
            cikoPictureBox.Size = new Size(200, 109);
            cikoPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            cikoPictureBox.TabIndex = 8;
            cikoPictureBox.TabStop = false;
            cikoPictureBox.Click += cikoPictureBox_Click;
            // 
            // meyvePictureBox
            // 
            meyvePictureBox.BackColor = SystemColors.ControlLightLight;
            meyvePictureBox.Cursor = Cursors.Hand;
            meyvePictureBox.Image = Resource1.shop_supermarket_fruits_store_grocery_icon_229141;
            meyvePictureBox.Location = new Point(394, 110);
            meyvePictureBox.Name = "meyvePictureBox";
            meyvePictureBox.Size = new Size(200, 109);
            meyvePictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            meyvePictureBox.TabIndex = 7;
            meyvePictureBox.TabStop = false;
            meyvePictureBox.Click += meyvePictureBox_Click;
            // 
            // colaPictureBox
            // 
            colaPictureBox.BackColor = SystemColors.ControlLightLight;
            colaPictureBox.Cursor = Cursors.Hand;
            colaPictureBox.Image = Resource1.soda_can_icon_1256661;
            colaPictureBox.Location = new Point(198, 110);
            colaPictureBox.Name = "colaPictureBox";
            colaPictureBox.Size = new Size(200, 109);
            colaPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            colaPictureBox.TabIndex = 6;
            colaPictureBox.TabStop = false;
            colaPictureBox.Click += colaPictureBox_Click;
            // 
            // cheesePictureBox
            // 
            cheesePictureBox.BackColor = SystemColors.ControlLightLight;
            cheesePictureBox.Cursor = Cursors.Hand;
            cheesePictureBox.Image = Resource1.cheese_food_5426;
            cheesePictureBox.Location = new Point(3, 110);
            cheesePictureBox.Name = "cheesePictureBox";
            cheesePictureBox.Size = new Size(200, 109);
            cheesePictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            cheesePictureBox.TabIndex = 5;
            cheesePictureBox.TabStop = false;
            cheesePictureBox.Click += cheesePictureBox_Click;
            // 
            // eggPictureBox
            // 
            eggPictureBox.BackColor = SystemColors.ControlLightLight;
            eggPictureBox.Cursor = Cursors.Hand;
            eggPictureBox.Image = Resource1.egg_icon_125749;
            eggPictureBox.Location = new Point(394, 0);
            eggPictureBox.Name = "eggPictureBox";
            eggPictureBox.Size = new Size(200, 109);
            eggPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            eggPictureBox.TabIndex = 4;
            eggPictureBox.TabStop = false;
            eggPictureBox.Click += eggPictureBox_Click;
            // 
            // milkPictureBox
            // 
            milkPictureBox.BackColor = SystemColors.ControlLightLight;
            milkPictureBox.Cursor = Cursors.Hand;
            milkPictureBox.Image = Resource1.milk_drink_icon_134147;
            milkPictureBox.Location = new Point(198, 0);
            milkPictureBox.Name = "milkPictureBox";
            milkPictureBox.Size = new Size(200, 109);
            milkPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            milkPictureBox.TabIndex = 3;
            milkPictureBox.TabStop = false;
            milkPictureBox.Click += milkPictureBox_Click_1;
            // 
            // ekmekPictureBox
            // 
            ekmekPictureBox.BackColor = SystemColors.ControlLightLight;
            ekmekPictureBox.Cursor = Cursors.Hand;
            ekmekPictureBox.Image = Resource1.bread_food_4690__2_;
            ekmekPictureBox.Location = new Point(3, 0);
            ekmekPictureBox.Name = "ekmekPictureBox";
            ekmekPictureBox.Size = new Size(200, 109);
            ekmekPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
            ekmekPictureBox.TabIndex = 2;
            ekmekPictureBox.TabStop = false;
            ekmekPictureBox.Click += ekmekPictureBox_Click_1;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(3, 103);
            label1.Name = "label1";
            label1.Size = new Size(182, 30);
            label1.TabIndex = 0;
            label1.Text = "Market";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = Resource1.market;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(188, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(sampPictureBox);
            panel3.Controls.Add(deterjanPictureBox);
            panel3.Controls.Add(cipsPictureBox);
            panel3.Controls.Add(sebzePictureBox);
            panel3.Controls.Add(suPictureBox);
            panel3.Controls.Add(cikoPictureBox);
            panel3.Controls.Add(meyvePictureBox);
            panel3.Controls.Add(colaPictureBox);
            panel3.Controls.Add(cheesePictureBox);
            panel3.Controls.Add(eggPictureBox);
            panel3.Controls.Add(milkPictureBox);
            panel3.Controls.Add(ekmekPictureBox);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(188, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(597, 437);
            panel3.TabIndex = 5;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Control;
            button2.Dock = DockStyle.Bottom;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 12F);
            button2.Location = new Point(0, 375);
            button2.Name = "button2";
            button2.Size = new Size(188, 62);
            button2.TabIndex = 4;
            button2.Text = "Sepetim";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Control;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(188, 437);
            panel1.TabIndex = 3;
            // 
            // FormMusteri
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(785, 437);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FormMusteri";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Market";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)sampPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)deterjanPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)cipsPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)sebzePictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)suPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)cikoPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)meyvePictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)colaPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)cheesePictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)eggPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)milkPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)ekmekPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox sampPictureBox;
        private PictureBox deterjanPictureBox;
        private PictureBox cipsPictureBox;
        private PictureBox sebzePictureBox;
        private PictureBox suPictureBox;
        private PictureBox cikoPictureBox;
        private PictureBox meyvePictureBox;
        private PictureBox colaPictureBox;
        private PictureBox cheesePictureBox;
        private PictureBox eggPictureBox;
        private PictureBox milkPictureBox;
        private PictureBox ekmekPictureBox;
        private Label label1;
        private PictureBox pictureBox1;
        private Panel panel3;
        private Panel panel1;
        private Button button2;
    }
}